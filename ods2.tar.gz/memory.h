/*
 *  Empty placeholder file for VAX C, which doesn't have (or need) <memory.h>
 */
